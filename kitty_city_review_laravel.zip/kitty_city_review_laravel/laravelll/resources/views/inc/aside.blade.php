@section('aside')
<div class="aside" style="border:px solid black; display:flex; flex-direction: column; align-items: center; justify-content: center; height: 300px;">
    <h4>Most popular reviews</h4>
    <img src="{{ asset('empty.png') }}" alt="Empty Image" style="width:200px; border:0px solid black;">
</div>
<!--@show - from parent in home-->



