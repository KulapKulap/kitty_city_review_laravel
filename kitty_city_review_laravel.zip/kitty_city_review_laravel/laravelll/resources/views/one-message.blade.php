
@extends('layouts.app')

@section('title')
<h1>{{$data->subject}}</h1>
@endsection('title')

@section('content')
<h1>{{$data->subject}}</h1>
    <div class="alert alert-info">
        <h4>{{$data->message}}</h4>
        <h4>{{$data->email}}</h4>
        <a href="{{route('contact-data-one', $data->id)}}"><button class="btn btn-warning">details</button></a>
    </div>

@endsection('content')








@section('aside')
    @parent
    <p>huiiiiiiii</p>
@endsection