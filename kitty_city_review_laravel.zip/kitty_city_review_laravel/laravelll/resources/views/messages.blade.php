
@extends('layouts.app')

@section('title')
<h1>messages</h1>
@endsection('title')

@section('content')
<h1>messages</h1>
    @foreach($data as $el)
    <div class="alert alert-info">
        <h3>{{$el->subject}}</h3>
        <h4>{{$el->email}}</h4>
        <p><small>{{$el->created_at}}</small></p>
        <a href="{{route('contact-data-one', $el->id)}}"><button class="btn btn-warning">Read Review</button></a>
    </div>

    @endforeach
@endsection('content')








@section('aside')
    @parent
    <p>huiiiiiiii</p>
@endsection