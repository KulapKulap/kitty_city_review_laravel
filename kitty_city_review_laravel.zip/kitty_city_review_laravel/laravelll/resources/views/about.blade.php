@extends('layouts.app')

@section('title')
<h1>about</h1>
@endsection('title')

@section('content')
<h1>empty</h1>
@endsection('content')