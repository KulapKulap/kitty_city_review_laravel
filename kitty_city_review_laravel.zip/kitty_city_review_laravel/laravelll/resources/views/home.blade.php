
@extends('layouts.app')

@section('title')
<h1>home</h1>
@endsection('title')

@section('content')
<h1></h1>
@endsection('content')

@section('aside')
    @parent
    <p></p>
@endsection