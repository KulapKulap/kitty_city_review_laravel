<?php $__env->startSection('title'); ?>
<h1><?php echo e($data->subject); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1><?php echo e($data->subject); ?></h1>
    <div class="alert alert-info">
        <h4><?php echo e($data->message); ?></h4>
        <h4><?php echo e($data->email); ?></h4>
        <a href="<?php echo e(route('contact-data-one', $data->id)); ?>"><button class="btn btn-warning">details</button></a>
    </div>

<?php $__env->stopSection(); ?>








<?php $__env->startSection('aside'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('aside'); ?>
    <p>huiiiiiiii</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/xampp_htdocs_laravelll/laravelll/resources/views/one-message.blade.php ENDPATH**/ ?>