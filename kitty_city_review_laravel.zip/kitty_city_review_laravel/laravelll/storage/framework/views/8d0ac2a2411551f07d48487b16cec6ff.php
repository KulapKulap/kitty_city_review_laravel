<?php $__env->startSection('title'); ?>
<h1>contact</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>contact</h1>




<form action="<?php echo e(route('contact-form')); ?>" method="post">
<?php echo csrf_field(); ?> <!-- This is crucial for CSRF protection -->
    <div class="form-group">
        <label for="name">Your name</label>
        <input type="text" name="name" id="name" placeholder="Ex: Meatball" class=form-control>
    </div>
    <br>

    <div class="form-group">
        <label for="email">Your email</label>
        <input type="text" name="email" id="email" placeholder="Ex: meatball@gmail.com" class=form-control>
    </div>
    <br>
    <div class="form-group">
        <label for="title">Place</label>
        <input type="text" name="subject" id="subject" placeholder="Ex: Claw Plates" class=form-control>
    </div>
    <br>
    <div class="form-group">
        <label for="message">Review</label>
        <textarea type="text" name="message" id="message" placeholder="drop a line" class=form-control></textarea>
    </div>
    <br>
    <button type="submit">Submit 🐾</button>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/xampp_htdocs_laravelll/laravelll/resources/views/contact.blade.php ENDPATH**/ ?>