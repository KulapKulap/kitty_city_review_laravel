<?php $__env->startSection('aside'); ?>
<div class="aside" style="border:px solid black; display:flex; flex-direction: column; align-items: center; justify-content: center; height: 300px;">
    <h4>Most popular reviews</h4>
    <img src="<?php echo e(asset('empty.png')); ?>" alt="Empty Image" style="width:200px; border:0px solid black;">
</div>
<!--<?php echo $__env->yieldSection(); ?> - from parent in home-->



<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/xampp_htdocs_laravelll/laravelll/resources/views/inc/aside.blade.php ENDPATH**/ ?>